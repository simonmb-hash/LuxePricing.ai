LuxePricing.ai Streamlit App - Complete Version

This is the improved integrated app with all 7 deliverables included inside 4 main sections:

1. Live Demo & Analytics
   - AI Agent Demo
   - Daily BAR recommendation
   - Competitor rate-shopper simulation
   - Demand calendar
   - Approval queue and audit trail

2. Operations & Finance
   - CRM ingestion source map
   - Automated data quality monitor
   - Exception queue
   - Clean export
   - AI ROI calculator for pricing uplift scenarios
   - USALI-style current vs scenario bridge

3. Data Science Sandbox
   - Synthetic guest data generator
   - Pricing elasticity model
   - Segment elasticity chart
   - Demand curve and recommended ADR

4. GTM Strategy & Corporate
   - AI brand identity generator
   - Automated luxury ad engine
   - AI sales outreach and demo scripts
   - AI-generated CRO role profile
   - Revenue org design and KPI scorecard

HOW TO RUN ON WINDOWS:
1. Unzip the folder.
2. Double-click run_luxepricing_windows.bat.
3. Keep the command window open.
4. The app should open in your browser.

HOW TO RUN ON MAC:
1. Unzip the folder.
2. Right click run_luxepricing_mac.command > Open.
3. If permission is blocked, open Terminal in the folder and run:
   chmod +x run_luxepricing_mac.command
   ./run_luxepricing_mac.command

Manual command:
pip install -r requirements.txt
streamlit run app.py
